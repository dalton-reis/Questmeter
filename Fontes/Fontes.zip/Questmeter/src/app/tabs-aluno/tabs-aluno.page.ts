import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aluno-inicio-tabs-aluno',
  templateUrl: './tabs-aluno.page.html',
  styleUrls: ['./tabs-aluno.page.scss'],
})
export class TabsAlunoPage { }

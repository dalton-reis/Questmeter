import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-professor-inicio',
  templateUrl: './professor-inicio.page.html',
  styleUrls: ['./professor-inicio.page.scss'],
})
export class ProfessorInicioPage implements OnInit {

  constructor() { }
 
  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aluno-inicio',
  templateUrl: './aluno-inicio.page.html',
  styleUrls: ['./aluno-inicio.page.scss'],
})
export class AlunoInicioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

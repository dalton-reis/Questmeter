import { Component } from '@angular/core';

@Component({
  selector: 'professor-inicio-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage {}

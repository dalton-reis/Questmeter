export interface IProfessor {
    id?: string;
    usuario: string;
    nomeCompleto: string;
    imagem: string;
}

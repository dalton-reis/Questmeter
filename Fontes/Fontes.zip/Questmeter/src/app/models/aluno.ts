export interface IAluno {
    id?: string;
    usuario: string;
    nomeCompleto: string;
    imagem: string;
    nivel: number;
    pontuacao: number;
}

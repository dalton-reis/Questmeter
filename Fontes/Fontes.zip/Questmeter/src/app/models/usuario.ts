export class Usuario {
    email: string;
    senha: string;
}

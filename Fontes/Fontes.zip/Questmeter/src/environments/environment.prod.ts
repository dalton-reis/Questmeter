export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBsLrBR1oyxm2bvH61vCySKvAHYZ9X6JGo",
    authDomain: "apptcc-3dc7d.firebaseapp.com",
    databaseURL: "https://apptcc-3dc7d.firebaseio.com",
    projectId: "apptcc-3dc7d",
    storageBucket: "apptcc-3dc7d.appspot.com",
    messagingSenderId: "43188714928"
  }
};

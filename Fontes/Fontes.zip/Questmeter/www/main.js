(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./1fcq78hk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.entry.js",
		"common",
		102
	],
	"./1fcq78hk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.sc.entry.js",
		"common",
		103
	],
	"./2i50w2lv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.entry.js",
		"common",
		104
	],
	"./2i50w2lv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.sc.entry.js",
		"common",
		105
	],
	"./39fhulxe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.entry.js",
		"common",
		106
	],
	"./39fhulxe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.sc.entry.js",
		"common",
		107
	],
	"./3hbcnxuc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.entry.js",
		"common",
		58
	],
	"./3hbcnxuc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.sc.entry.js",
		"common",
		59
	],
	"./3pkkvczk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.entry.js",
		0,
		"common",
		128
	],
	"./3pkkvczk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.sc.entry.js",
		0,
		"common",
		129
	],
	"./48sex9p5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/48sex9p5.entry.js",
		"common",
		60
	],
	"./48sex9p5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/48sex9p5.sc.entry.js",
		"common",
		61
	],
	"./5klmpbas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5klmpbas.entry.js",
		2,
		"common",
		130
	],
	"./5klmpbas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5klmpbas.sc.entry.js",
		2,
		"common",
		131
	],
	"./5zcdwzsx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.entry.js",
		"common",
		10
	],
	"./5zcdwzsx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.sc.entry.js",
		"common",
		11
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		"common",
		12
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		"common",
		13
	],
	"./7hlpr3fd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.entry.js",
		0,
		"common",
		132
	],
	"./7hlpr3fd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.sc.entry.js",
		0,
		"common",
		133
	],
	"./91yswq9n.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/91yswq9n.entry.js",
		"common",
		62
	],
	"./91yswq9n.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/91yswq9n.sc.entry.js",
		"common",
		63
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		"common",
		64
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		"common",
		65
	],
	"./ak14tg4e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ak14tg4e.entry.js",
		"common",
		66
	],
	"./ak14tg4e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ak14tg4e.sc.entry.js",
		"common",
		67
	],
	"./azzrjyyu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.entry.js",
		0,
		"common",
		134
	],
	"./azzrjyyu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.sc.entry.js",
		0,
		"common",
		135
	],
	"./b65tzyas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.entry.js",
		"common",
		14
	],
	"./b65tzyas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.sc.entry.js",
		"common",
		15
	],
	"./b7geaofq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b7geaofq.entry.js",
		"common",
		68
	],
	"./b7geaofq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b7geaofq.sc.entry.js",
		"common",
		69
	],
	"./bb7q7tld.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.entry.js",
		"common",
		108
	],
	"./bb7q7tld.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.sc.entry.js",
		"common",
		109
	],
	"./bheoje2y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bheoje2y.entry.js",
		"common",
		16
	],
	"./bheoje2y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bheoje2y.sc.entry.js",
		"common",
		17
	],
	"./d1xzdckz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d1xzdckz.entry.js",
		"common",
		18
	],
	"./d1xzdckz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d1xzdckz.sc.entry.js",
		"common",
		19
	],
	"./devt5yhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.entry.js",
		0,
		"common",
		138
	],
	"./devt5yhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.sc.entry.js",
		0,
		"common",
		139
	],
	"./djkq5plb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.entry.js",
		"common",
		70
	],
	"./djkq5plb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.sc.entry.js",
		"common",
		71
	],
	"./eem8jsfz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eem8jsfz.entry.js",
		"common",
		20
	],
	"./eem8jsfz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eem8jsfz.sc.entry.js",
		"common",
		21
	],
	"./eghwkqif.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.entry.js",
		"common",
		22
	],
	"./eghwkqif.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.sc.entry.js",
		"common",
		23
	],
	"./ek05jvfc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.entry.js",
		"common",
		24
	],
	"./ek05jvfc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.sc.entry.js",
		"common",
		25
	],
	"./f5r41bls.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f5r41bls.entry.js",
		0,
		"common",
		110
	],
	"./f5r41bls.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f5r41bls.sc.entry.js",
		0,
		"common",
		111
	],
	"./fkzdmlip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.entry.js",
		140
	],
	"./fkzdmlip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.sc.entry.js",
		141
	],
	"./fmzmhk3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.entry.js",
		"common",
		72
	],
	"./fmzmhk3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.sc.entry.js",
		"common",
		73
	],
	"./foblon1x.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/foblon1x.entry.js",
		"common",
		26
	],
	"./foblon1x.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/foblon1x.sc.entry.js",
		"common",
		27
	],
	"./hds9xywu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hds9xywu.entry.js",
		"common",
		114
	],
	"./hds9xywu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hds9xywu.sc.entry.js",
		"common",
		115
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		142
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		143
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		"common",
		74
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		"common",
		75
	],
	"./imcdx1xe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.entry.js",
		"common",
		116
	],
	"./imcdx1xe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.sc.entry.js",
		"common",
		117
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		"common",
		76
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		"common",
		77
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		"common",
		78
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		"common",
		79
	],
	"./iwgahuhw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.entry.js",
		"common",
		28
	],
	"./iwgahuhw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.sc.entry.js",
		"common",
		29
	],
	"./j20d1ikn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.entry.js",
		"common",
		80
	],
	"./j20d1ikn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.sc.entry.js",
		"common",
		81
	],
	"./jyhraxns.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyhraxns.entry.js",
		"common",
		98
	],
	"./jyhraxns.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyhraxns.sc.entry.js",
		"common",
		99
	],
	"./jzwyowjw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.entry.js",
		"common",
		30
	],
	"./jzwyowjw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.sc.entry.js",
		"common",
		31
	],
	"./k6eoch7h.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.entry.js",
		0,
		"common",
		144
	],
	"./k6eoch7h.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.sc.entry.js",
		0,
		"common",
		145
	],
	"./kawnb1ql.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kawnb1ql.entry.js",
		"common",
		82
	],
	"./kawnb1ql.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kawnb1ql.sc.entry.js",
		"common",
		83
	],
	"./kgjnfunx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.entry.js",
		"common",
		32
	],
	"./kgjnfunx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.sc.entry.js",
		"common",
		33
	],
	"./lb8tayd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.entry.js",
		"common",
		118
	],
	"./lb8tayd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.sc.entry.js",
		"common",
		119
	],
	"./llyqw4no.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.entry.js",
		"common",
		84
	],
	"./llyqw4no.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.sc.entry.js",
		"common",
		85
	],
	"./mf2ayo12.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.entry.js",
		"common",
		34
	],
	"./mf2ayo12.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.sc.entry.js",
		"common",
		35
	],
	"./mo7qeek2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.entry.js",
		"common",
		120
	],
	"./mo7qeek2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.sc.entry.js",
		"common",
		121
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		146
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		147
	],
	"./mrs0ks1r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.entry.js",
		0,
		"common",
		148
	],
	"./mrs0ks1r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.sc.entry.js",
		0,
		"common",
		149
	],
	"./n1gqnu4m.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n1gqnu4m.entry.js",
		"common",
		86
	],
	"./n1gqnu4m.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n1gqnu4m.sc.entry.js",
		"common",
		87
	],
	"./n60sde1b.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n60sde1b.entry.js",
		"common",
		36
	],
	"./n60sde1b.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n60sde1b.sc.entry.js",
		"common",
		37
	],
	"./oc7j8k7y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.entry.js",
		"common",
		122
	],
	"./oc7j8k7y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.sc.entry.js",
		"common",
		123
	],
	"./oiucdv63.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiucdv63.entry.js",
		"common",
		88
	],
	"./oiucdv63.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiucdv63.sc.entry.js",
		"common",
		89
	],
	"./pd9wflli.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.entry.js",
		"common",
		100
	],
	"./pd9wflli.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.sc.entry.js",
		"common",
		101
	],
	"./qzdsdbvt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qzdsdbvt.entry.js",
		"common",
		90
	],
	"./qzdsdbvt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qzdsdbvt.sc.entry.js",
		"common",
		91
	],
	"./r2tscfp8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r2tscfp8.entry.js",
		0,
		"common",
		112
	],
	"./r2tscfp8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r2tscfp8.sc.entry.js",
		0,
		"common",
		113
	],
	"./r8dtlwvb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.entry.js",
		0,
		"common",
		150
	],
	"./r8dtlwvb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.sc.entry.js",
		0,
		"common",
		151
	],
	"./r8g3twaz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8g3twaz.entry.js",
		"common",
		38
	],
	"./r8g3twaz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8g3twaz.sc.entry.js",
		"common",
		39
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		"common",
		124
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		"common",
		125
	],
	"./ro1otaal.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ro1otaal.entry.js",
		2,
		"common",
		152
	],
	"./ro1otaal.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ro1otaal.sc.entry.js",
		2,
		"common",
		153
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		154
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		155
	],
	"./senscofp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.entry.js",
		"common",
		40
	],
	"./senscofp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.sc.entry.js",
		"common",
		41
	],
	"./tg9wqmdk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tg9wqmdk.entry.js",
		0,
		"common",
		156
	],
	"./tg9wqmdk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tg9wqmdk.sc.entry.js",
		0,
		"common",
		157
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		"common",
		42
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		"common",
		43
	],
	"./tn7df4wj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.entry.js",
		"common",
		126
	],
	"./tn7df4wj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.sc.entry.js",
		"common",
		127
	],
	"./ugd3sahs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugd3sahs.entry.js",
		"common",
		92
	],
	"./ugd3sahs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugd3sahs.sc.entry.js",
		"common",
		93
	],
	"./uhyavx6a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.entry.js",
		0,
		"common",
		158
	],
	"./uhyavx6a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.sc.entry.js",
		0,
		"common",
		159
	],
	"./upnvzchf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upnvzchf.entry.js",
		"common",
		44
	],
	"./upnvzchf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upnvzchf.sc.entry.js",
		"common",
		45
	],
	"./urrnn8ys.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/urrnn8ys.entry.js",
		"common",
		46
	],
	"./urrnn8ys.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/urrnn8ys.sc.entry.js",
		"common",
		47
	],
	"./vompwuhi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.entry.js",
		"common",
		48
	],
	"./vompwuhi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.sc.entry.js",
		"common",
		49
	],
	"./vypdotd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.entry.js",
		"common",
		50
	],
	"./vypdotd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.sc.entry.js",
		"common",
		51
	],
	"./wb4mk1b9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.entry.js",
		0,
		"common",
		160
	],
	"./wb4mk1b9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.sc.entry.js",
		0,
		"common",
		161
	],
	"./wddurbsg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wddurbsg.entry.js",
		"common",
		52
	],
	"./wddurbsg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wddurbsg.sc.entry.js",
		"common",
		53
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		"common",
		94
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		"common",
		95
	],
	"./wpufhrqd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpufhrqd.entry.js",
		"common",
		54
	],
	"./wpufhrqd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpufhrqd.sc.entry.js",
		"common",
		55
	],
	"./wrpzmdqx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.entry.js",
		"common",
		56
	],
	"./wrpzmdqx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.sc.entry.js",
		"common",
		57
	],
	"./wwcmkxu8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wwcmkxu8.entry.js",
		0,
		"common",
		162
	],
	"./wwcmkxu8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wwcmkxu8.sc.entry.js",
		0,
		"common",
		163
	],
	"./x5xnv4jv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.entry.js",
		0,
		"common",
		164
	],
	"./x5xnv4jv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.sc.entry.js",
		0,
		"common",
		165
	],
	"./xajhwvib.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.entry.js",
		"common",
		96
	],
	"./xajhwvib.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.sc.entry.js",
		"common",
		97
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../pages/aluno-atividade-codigo/aluno-atividade-codigo.module": [
		"./src/app/pages/aluno-atividade-codigo/aluno-atividade-codigo.module.ts",
		"common",
		"pages-aluno-atividade-codigo-aluno-atividade-codigo-module"
	],
	"../pages/aluno-atividade/aluno-atividade.module": [
		"./src/app/pages/aluno-atividade/aluno-atividade.module.ts",
		"common",
		"pages-aluno-atividade-aluno-atividade-module"
	],
	"../pages/aluno-perfil/aluno-perfil.module": [
		"./src/app/pages/aluno-perfil/aluno-perfil.module.ts",
		"common",
		"pages-aluno-perfil-aluno-perfil-module"
	],
	"../pages/professor-atividade/professor-atividade.module": [
		"./src/app/pages/professor-atividade/professor-atividade.module.ts",
		"common",
		"pages-professor-atividade-professor-atividade-module"
	],
	"../pages/professor-perfil/professor-perfil.module": [
		"./src/app/pages/professor-perfil/professor-perfil.module.ts",
		"common",
		"pages-professor-perfil-professor-perfil-module"
	],
	"./pages/abertura/abertura.module": [
		"./src/app/pages/abertura/abertura.module.ts",
		"pages-abertura-abertura-module"
	],
	"./pages/aluno-atividade-abrir/aluno-atividade-abrir.module": [
		"./src/app/pages/aluno-atividade-abrir/aluno-atividade-abrir.module.ts",
		"default~pages-aluno-atividade-abrir-aluno-atividade-abrir-module~pages-professor-atividade-apresenta~bd8a083d",
		"common",
		"pages-aluno-atividade-abrir-aluno-atividade-abrir-module"
	],
	"./pages/aluno-atividade/aluno-atividade.module": [
		"./src/app/pages/aluno-atividade/aluno-atividade.module.ts",
		"common",
		"pages-aluno-atividade-aluno-atividade-module"
	],
	"./pages/aluno-inicio/aluno-inicio.module": [
		"./src/app/pages/aluno-inicio/aluno-inicio.module.ts",
		"pages-aluno-inicio-aluno-inicio-module"
	],
	"./pages/aluno-resposta/aluno-resposta.module": [
		"./src/app/pages/aluno-resposta/aluno-resposta.module.ts",
		"common",
		"pages-aluno-resposta-aluno-resposta-module"
	],
	"./pages/autenticacao-criar-conta/autenticacao-criar-conta.module": [
		"./src/app/pages/autenticacao-criar-conta/autenticacao-criar-conta.module.ts",
		"common",
		"pages-autenticacao-criar-conta-autenticacao-criar-conta-module"
	],
	"./pages/autenticacao-resetar-senha/autenticacao-resetar-senha.module": [
		"./src/app/pages/autenticacao-resetar-senha/autenticacao-resetar-senha.module.ts",
		"common",
		"pages-autenticacao-resetar-senha-autenticacao-resetar-senha-module"
	],
	"./pages/autenticacao/autenticacao.module": [
		"./src/app/pages/autenticacao/autenticacao.module.ts",
		"common",
		"pages-autenticacao-autenticacao-module"
	],
	"./pages/professor-atividade-apresentacao-ranking/professor-atividade-apresentacao-ranking.module": [
		"./src/app/pages/professor-atividade-apresentacao-ranking/professor-atividade-apresentacao-ranking.module.ts",
		"common",
		"pages-professor-atividade-apresentacao-ranking-professor-atividade-apresentacao-ranking-module"
	],
	"./pages/professor-atividade-apresentacao-turma/professor-atividade-apresentacao-turma.module": [
		"./src/app/pages/professor-atividade-apresentacao-turma/professor-atividade-apresentacao-turma.module.ts",
		"common",
		"pages-professor-atividade-apresentacao-turma-professor-atividade-apresentacao-turma-module"
	],
	"./pages/professor-atividade-apresentacao/professor-atividade-apresentacao.module": [
		"./src/app/pages/professor-atividade-apresentacao/professor-atividade-apresentacao.module.ts",
		"default~pages-aluno-atividade-abrir-aluno-atividade-abrir-module~pages-professor-atividade-apresenta~bd8a083d",
		"common",
		"pages-professor-atividade-apresentacao-professor-atividade-apresentacao-module"
	],
	"./pages/professor-atividade-criacao/professor-atividade-criacao.module": [
		"./src/app/pages/professor-atividade-criacao/professor-atividade-criacao.module.ts",
		"common",
		"pages-professor-atividade-criacao-professor-atividade-criacao-module"
	],
	"./pages/professor-atividade-edicao/professor-atividade-edicao.module": [
		"./src/app/pages/professor-atividade-edicao/professor-atividade-edicao.module.ts",
		"common",
		"pages-professor-atividade-edicao-professor-atividade-edicao-module"
	],
	"./pages/professor-atividade/professor-atividade.module": [
		"./src/app/pages/professor-atividade/professor-atividade.module.ts",
		"common",
		"pages-professor-atividade-professor-atividade-module"
	],
	"./pages/professor-inicio/professor-inicio.module": [
		"./src/app/pages/professor-inicio/professor-inicio.module.ts",
		"pages-professor-inicio-professor-inicio-module"
	],
	"./pages/professor-questao-edicao/professor-questao-edicao.module": [
		"./src/app/pages/professor-questao-edicao/professor-questao-edicao.module.ts",
		"common",
		"pages-professor-questao-edicao-professor-questao-edicao-module"
	],
	"./pages/professor-questao/professor-questao.module": [
		"./src/app/pages/professor-questao/professor-questao.module.ts",
		"common",
		"pages-professor-questao-professor-questao-module"
	],
	"./pages/professor-resposta/professor-resposta.module": [
		"./src/app/pages/professor-resposta/professor-resposta.module.ts",
		"common",
		"pages-professor-resposta-professor-resposta-module"
	],
	"./pages/professor-turma-edicao/professor-turma-edicao.module": [
		"./src/app/pages/professor-turma-edicao/professor-turma-edicao.module.ts",
		"common",
		"pages-professor-turma-edicao-professor-turma-edicao-module"
	],
	"./pages/professor-turma/professor-turma.module": [
		"./src/app/pages/professor-turma/professor-turma.module.ts",
		"common",
		"pages-professor-turma-professor-turma-module"
	],
	"src/app/pages/aluno-atividade-abrir/aluno-atividade-abrir.module": [
		"./src/app/pages/aluno-atividade-abrir/aluno-atividade-abrir.module.ts",
		"default~pages-aluno-atividade-abrir-aluno-atividade-abrir-module~pages-professor-atividade-apresenta~bd8a083d",
		"common",
		"pages-aluno-atividade-abrir-aluno-atividade-abrir-module"
	],
	"src/app/pages/aluno-atividade-codigo/aluno-atividade-codigo.module": [
		"./src/app/pages/aluno-atividade-codigo/aluno-atividade-codigo.module.ts",
		"common",
		"pages-aluno-atividade-codigo-aluno-atividade-codigo-module"
	],
	"src/app/pages/aluno-atividade/aluno-atividade.module": [
		"./src/app/pages/aluno-atividade/aluno-atividade.module.ts",
		"common",
		"pages-aluno-atividade-aluno-atividade-module"
	],
	"src/app/pages/aluno-perfil/aluno-perfil.module": [
		"./src/app/pages/aluno-perfil/aluno-perfil.module.ts",
		"common",
		"pages-aluno-perfil-aluno-perfil-module"
	],
	"src/app/pages/professor-atividade-criacao/professor-atividade-criacao.module": [
		"./src/app/pages/professor-atividade-criacao/professor-atividade-criacao.module.ts",
		"common",
		"pages-professor-atividade-criacao-professor-atividade-criacao-module"
	],
	"src/app/pages/professor-atividade-edicao/professor-atividade-edicao.module": [
		"./src/app/pages/professor-atividade-edicao/professor-atividade-edicao.module.ts",
		"common",
		"pages-professor-atividade-edicao-professor-atividade-edicao-module"
	],
	"src/app/pages/professor-atividade/professor-atividade.module": [
		"./src/app/pages/professor-atividade/professor-atividade.module.ts",
		"common",
		"pages-professor-atividade-professor-atividade-module"
	],
	"src/app/pages/professor-perfil/professor-perfil.module": [
		"./src/app/pages/professor-perfil/professor-perfil.module.ts",
		"common",
		"pages-professor-perfil-professor-perfil-module"
	],
	"src/app/pages/professor-resposta/professor-resposta.module": [
		"./src/app/pages/professor-resposta/professor-resposta.module.ts",
		"common",
		"pages-professor-resposta-professor-resposta-module"
	],
	"src/app/tabs-aluno/tabs-aluno.module": [
		"./src/app/tabs-aluno/tabs-aluno.module.ts",
		"src-app-tabs-aluno-tabs-aluno-module"
	],
	"src/app/tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"src-app-tabs-tabs-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    { path: '', redirectTo: 'abertura', pathMatch: 'full' },
    { path: 'abertura', loadChildren: './pages/abertura/abertura.module#AberturaPageModule' },
    { path: 'autenticacao/:tipo', loadChildren: './pages/autenticacao/autenticacao.module#AutenticacaoPageModule' },
    { path: 'autenticacao-criar-conta/:tipo', loadChildren: './pages/autenticacao-criar-conta/autenticacao-criar-conta.module#AutenticacaoCriarContaPageModule' },
    { path: 'autenticacao-resetar-senha', loadChildren: './pages/autenticacao-resetar-senha/autenticacao-resetar-senha.module#AutenticacaoResetarSenhaPageModule' },
    { path: 'aluno-inicio', loadChildren: './pages/aluno-inicio/aluno-inicio.module#AlunoInicioPageModule' },
    { path: 'professor-inicio', loadChildren: './pages/professor-inicio/professor-inicio.module#ProfessorInicioPageModule' },
    { path: 'aluno-atividade', loadChildren: './pages/aluno-atividade/aluno-atividade.module#AlunoAtividadePageModule' },
    { path: 'aluno-atividade-abrir/turma/:turma', loadChildren: './pages/aluno-atividade-abrir/aluno-atividade-abrir.module#AlunoAtividadeAbrirPageModule' },
    { path: 'aluno-resposta/:id', loadChildren: './pages/aluno-resposta/aluno-resposta.module#AlunoRespostaPageModule' },
    { path: 'professor-atividade', loadChildren: './pages/professor-atividade/professor-atividade.module#ProfessorAtividadePageModule' },
    { path: 'professor-atividade-criacao', loadChildren: './pages/professor-atividade-criacao/professor-atividade-criacao.module#ProfessorAtividadeCriacaoPageModule' },
    { path: 'professor-atividade-edicao/:id', loadChildren: './pages/professor-atividade-edicao/professor-atividade-edicao.module#ProfessorAtividadeEdicaoPageModule' },
    { path: 'professor-resposta', loadChildren: './pages/professor-resposta/professor-resposta.module#ProfessorRespostaPageModule' },
    { path: 'professor-resposta/:id', loadChildren: './pages/professor-resposta/professor-resposta.module#ProfessorRespostaPageModule' },
    { path: 'professor-resposta/questao/:questao', loadChildren: './pages/professor-resposta/professor-resposta.module#ProfessorRespostaPageModule' },
    { path: 'professor-atividade-apresentacao/turma/:turma', loadChildren: './pages/professor-atividade-apresentacao/professor-atividade-apresentacao.module#ProfessorAtividadeApresentacaoPageModule' },
    { path: 'professor-questao', loadChildren: './pages/professor-questao/professor-questao.module#ProfessorQuestaoPageModule' },
    { path: 'professor-questao/:id', loadChildren: './pages/professor-questao/professor-questao.module#ProfessorQuestaoPageModule' },
    { path: 'professor-questao/atividade/:atividade', loadChildren: './pages/professor-questao/professor-questao.module#ProfessorQuestaoPageModule' },
    { path: 'professor-questao-edicao/:id', loadChildren: './pages/professor-questao-edicao/professor-questao-edicao.module#ProfessorQuestaoEdicaoPageModule' },
    { path: 'professor-turma/atividade/:atividade', loadChildren: './pages/professor-turma/professor-turma.module#ProfessorTurmaPageModule' },
    { path: 'professor-turma-edicao/:id', loadChildren: './pages/professor-turma-edicao/professor-turma-edicao.module#ProfessorTurmaEdicaoPageModule' },
    { path: 'professor-atividade-apresentacao-turma/atividade/:atividade', loadChildren: './pages/professor-atividade-apresentacao-turma/professor-atividade-apresentacao-turma.module#ProfessorAtividadeApresentacaoTurmaPageModule' },
    { path: 'professor-atividade-apresentacao-ranking/turma/:turma', loadChildren: './pages/professor-atividade-apresentacao-ranking/professor-atividade-apresentacao-ranking.module#ProfessorAtividadeApresentacaoRankingPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! angularfire2/auth */ "./node_modules/angularfire2/auth/index.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(angularfire2_auth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, nav, afAuth) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.nav = nav;
        this.afAuth = afAuth;
        this.afAuth.authState.subscribe(function (usuario) {
            if (usuario) {
                //this.nav.navigateForward('/');
            }
            else {
                //this.rootPage = SigninPage;
                //joga na pagina de login
            }
        });
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            angularfire2_auth__WEBPACK_IMPORTED_MODULE_1__["AngularFireAuth"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var angularfire2__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! angularfire2 */ "./node_modules/angularfire2/index.js");
/* harmony import */ var angularfire2__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(angularfire2__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var angularfire2_firestore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! angularfire2/firestore */ "./node_modules/angularfire2/firestore/index.js");
/* harmony import */ var angularfire2_firestore__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(angularfire2_firestore__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! angularfire2/auth */ "./node_modules/angularfire2/auth/index.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(angularfire2_auth__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");













var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
                angularfire2__WEBPACK_IMPORTED_MODULE_9__["AngularFireModule"].initializeApp(_environments_environment__WEBPACK_IMPORTED_MODULE_12__["environment"].firebaseConfig),
                angularfire2_firestore__WEBPACK_IMPORTED_MODULE_10__["AngularFirestoreModule"],
                angularfire2_auth__WEBPACK_IMPORTED_MODULE_11__["AngularFireAuthModule"]
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyBsLrBR1oyxm2bvH61vCySKvAHYZ9X6JGo",
        authDomain: "apptcc-3dc7d.firebaseapp.com",
        databaseURL: "https://apptcc-3dc7d.firebaseio.com",
        projectId: "apptcc-3dc7d",
        storageBucket: "apptcc-3dc7d.appspot.com",
        messagingSenderId: "43188714928"
    }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/daltonreis/Downloads/Questmeter/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map